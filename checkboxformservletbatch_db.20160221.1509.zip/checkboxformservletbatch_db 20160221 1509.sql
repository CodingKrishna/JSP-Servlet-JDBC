-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.86-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema sample
--

CREATE DATABASE IF NOT EXISTS sample;
USE sample;

--
-- Definition of table `user_languages_trn_tbl`
--

DROP TABLE IF EXISTS `user_languages_trn_tbl`;
CREATE TABLE `user_languages_trn_tbl` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `LANGUAGE_KNOWN` varchar(45) NOT NULL,
  `USER_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`ID`),
  KEY `FK_user_languages_trn_tbl_1` (`USER_ID`),
  CONSTRAINT `FK_user_languages_trn_tbl_1` FOREIGN KEY (`USER_ID`) REFERENCES `user_trn_tbl` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_languages_trn_tbl`
--

/*!40000 ALTER TABLE `user_languages_trn_tbl` DISABLE KEYS */;
INSERT INTO `user_languages_trn_tbl` (`ID`,`LANGUAGE_KNOWN`,`USER_ID`) VALUES 
 (1,'ENGLISH',1),
 (2,'ENGLISH',2),
 (3,'TELUGU',3),
 (4,'HINDI',3),
 (5,'ENGLISH',3),
 (6,'HINDI',4),
 (7,'KANNADA',4),
 (8,'ENGLISH',4),
 (9,'TELUGU',5),
 (10,'HINDI',5),
 (11,'KANNADA',5),
 (12,'ENGLISH',5);
/*!40000 ALTER TABLE `user_languages_trn_tbl` ENABLE KEYS */;


--
-- Definition of table `user_trn_tbl`
--

DROP TABLE IF EXISTS `user_trn_tbl`;
CREATE TABLE `user_trn_tbl` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `USER_NAME` varchar(45) NOT NULL,
  `EMAIL_ID` varchar(45) NOT NULL,
  `AGE` float NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_trn_tbl`
--

/*!40000 ALTER TABLE `user_trn_tbl` DISABLE KEYS */;
INSERT INTO `user_trn_tbl` (`ID`,`USER_NAME`,`EMAIL_ID`,`AGE`) VALUES 
 (1,'Viswa Swaroop Reddy','swaroop.viswa@gmail.com',6),
 (2,'Viswa Swaroop Reddy','swaroop.viswa@gmail.com',6),
 (3,'Viswa Swaroop Reddy','swaroop.viswa@gmail.com',6),
 (4,'Viswa Swaroop Reddy','amma@gmail.com',22),
 (5,'Manikanta Viswa','manikantaviswa',28);
/*!40000 ALTER TABLE `user_trn_tbl` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
