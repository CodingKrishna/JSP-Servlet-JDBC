-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.86-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema student
--

CREATE DATABASE IF NOT EXISTS student;
USE student;

--
-- Definition of table `studentdata`
--

DROP TABLE IF EXISTS `studentdata`;
CREATE TABLE `studentdata` (
  `stid` int(10) unsigned NOT NULL auto_increment,
  `sname` varchar(45) NOT NULL,
  `phnum` longtext NOT NULL,
  PRIMARY KEY  (`stid`)
) ENGINE=InnoDB AUTO_INCREMENT=548 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentdata`
--

/*!40000 ALTER TABLE `studentdata` DISABLE KEYS */;
INSERT INTO `studentdata` (`stid`,`sname`,`phnum`) VALUES 
 (502,'Anupama','9632587410'),
 (503,'KrishnaKanth','9854521369'),
 (504,'BhuvanaSri','9512358746'),
 (505,'Gayathri','9514236875'),
 (506,'VijayKumar','9854621345'),
 (507,'UmaDevi','9123456782'),
 (508,'Sudheer','8598986869'),
 (509,'Sangeetha','9698965879'),
 (510,'Sravani','9785439879'),
 (511,'Anusha','9854761230'),
 (512,'Chandini','9874563210'),
 (514,'Surendra','9632587410'),
 (546,'Suresh','9908685154'),
 (547,'Manikanta','9654782365');
/*!40000 ALTER TABLE `studentdata` ENABLE KEYS */;


--
-- Definition of table `studentdetails`
--

DROP TABLE IF EXISTS `studentdetails`;
CREATE TABLE `studentdetails` (
  `stid` int(10) unsigned NOT NULL auto_increment,
  `sname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phnum` longtext NOT NULL,
  `sscmaths` int(10) unsigned default '0',
  `ssceng` int(10) unsigned default '0',
  `sscscience` int(10) unsigned default '0',
  `intermaths` int(10) unsigned default '0',
  `intereng` int(10) unsigned default '0',
  `interscience` int(10) unsigned default '0',
  `ugmaths` int(10) unsigned default '0',
  `ugeng` int(10) unsigned default '0',
  `ugscience` int(10) unsigned default '0',
  PRIMARY KEY  (`stid`)
) ENGINE=InnoDB AUTO_INCREMENT=722 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentdetails`
--

/*!40000 ALTER TABLE `studentdetails` DISABLE KEYS */;
INSERT INTO `studentdetails` (`stid`,`sname`,`email`,`phnum`,`sscmaths`,`ssceng`,`sscscience`,`intermaths`,`intereng`,`interscience`,`ugmaths`,`ugeng`,`ugscience`) VALUES 
 (134,'Hari','suresh@gmail.com','7894562310',89,45,68,78,98,55,36,78,92),
 (143,'Suresh','suresh@gmail.com','9908685154',89,78,45,78,56,89,78,56,89),
 (501,'Suma Harika','suresh@gmail.com','9908685154',45,78,45,78,54,15,78,45,15),
 (502,'Uma Devi','sangeetha@gmail.com','9870134253',78,78,56,45,84,68,94,78,68),
 (503,'Krishna Kanth','suresh@gmail.com','9875642589',97,56,85,37,90,67,89,82,79),
 (504,'Bhuvana','suresh@gmail.com','9865425879',89,56,48,86,92,78,67,59,97),
 (505,'Umadevi B','suresh@gmail.com','9956559782',80,83,59,87,49,86,92,93,98),
 (512,'Chandini','chandini@gmail.com','8956457823',98,98,98,99,97,98,98,99,89),
 (546,'Suresh','suresh@gmail.com','9908685154',98,87,76,67,78,95,50,99,97),
 (600,'S Durgadevi123','durgadevi@gmail.com','9963619471',68,36,89,56,89,56,123,45,45),
 (721,'Anand','suresh@gmail.com','7894560123',78,58,78,29,89,89,58,87,99);
/*!40000 ALTER TABLE `studentdetails` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
