package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class SaveDetails {
	
	public void saveDetails(LinkedHashMap<String , String> lhm,Connection conn) {
		
		try {
			PreparedStatement stmt = conn.prepareStatement("insert into studentdata values(?,?,?)");
			
			Collection<?> c = lhm.values();
			Iterator<?> itr = c.iterator();
			int i = 1;
			while (itr.hasNext()) {
				String val = (String) itr.next();
				stmt.setString(i, val);
				System.out.println(val);
				i++;
			}
			stmt.executeUpdate();
			System.out.println("Successfully Inserted");
			stmt.close();
			//conn.close();
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	
	

}
