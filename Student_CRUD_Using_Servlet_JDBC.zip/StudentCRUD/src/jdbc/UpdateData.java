package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdateData {
	
	public void updateData(String stid,String sname,String phnum,Connection conn) {
		
		try {
			PreparedStatement stmt = conn.prepareStatement("update studentdata set sname=? , phnum=? where stid=?");
			stmt.setString(1, sname);
			stmt.setString(2, phnum);
			stmt.setString(3, stid);
			stmt.executeUpdate();
	
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			System.out.println("Successfully Updated");
		}
	}

}
