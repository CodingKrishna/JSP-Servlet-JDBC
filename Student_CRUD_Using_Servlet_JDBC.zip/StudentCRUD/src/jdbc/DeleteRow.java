package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DeleteRow {
	
	public void deleteRow(Connection conn,String stid) {
		
		try {
			
			PreparedStatement stmt = conn.prepareStatement("delete from student.studentdata where stid=?");
			stmt.setString(1, stid);
			stmt.executeUpdate();
			
			stmt.close();
			//conn.close();
				
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
