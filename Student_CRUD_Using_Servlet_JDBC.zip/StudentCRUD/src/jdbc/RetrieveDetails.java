package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class RetrieveDetails {

	public LinkedHashMap<Integer, ArrayList<String>> retrieveDetails(Connection conn) {
		LinkedHashMap<Integer, ArrayList<String>> lhm = new LinkedHashMap<Integer, ArrayList<String>>();

		try {
			
			PreparedStatement stmt = conn.prepareStatement("select * from studentdata");
			int i=1;
			ResultSet rs = stmt.executeQuery();
			
			
			
			
			System.out.println(rs);
			ResultSetMetaData rmd = rs.getMetaData();
			System.out.println("rmd.getCatalogName(1) :"+rmd.getCatalogName(1));
			System.out.println("getColumnClassName(1) :"+rmd.getColumnClassName(1));
			System.out.println("getColumnCount() :"+rmd.getColumnCount());
			System.out.println("getColumnDisplaySize(1) :"+rmd.getColumnDisplaySize(1));
			System.out.println("getColumnLabel(1) :"+rmd.getColumnLabel(1));
			System.out.println("getColumnName(1) :"+rmd.getColumnName(1));
			System.out.println("getColumnType(1) :"+rmd.getColumnType(1));
			System.out.println("getColumnTypeName(1) :"+rmd.getColumnTypeName(1));
			System.out.println("getPrecision(1) :"+rmd.getPrecision(1));
			System.out.println("getScale(1) :"+rmd.getScale(1));
			System.out.println("getSchemaName(1) :"+rmd.getSchemaName(1));
			System.out.println("getTableName(1) :"+rmd.getTableName(1));
			System.out.println("rmd.getClass() :"+rmd.getClass());
			System.out.println("hashCode() :"+rmd.hashCode());
			
			
			
			
			while (rs.next()) {

				ArrayList<String> aldata = new ArrayList<String>();

				String sid = rs.getString("stid");
				String name = rs.getString("sname");
				String phnum = rs.getString("phnum");
				aldata.add(sid);
				aldata.add(name);
				aldata.add(phnum);
				lhm.put(i, aldata);
				i++;	
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return lhm;
	}
}
