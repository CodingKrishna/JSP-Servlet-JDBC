package com.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.DetailsofStudent;

/**
 * Servlet implementation class RetrieveDetailsServlet
 */
public class RetrieveDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RetrieveDetailsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		DetailsofStudent ds = new DetailsofStudent();
		ArrayList<Map> al = ds.retrieveStudentDetails();
		//System.out.println(al);
		for (int i = 0; i < al.size(); i++) {

			HashMap<String, String> hm = (HashMap<String, String>) al.get(i);

			for (Map.Entry<String, String> entry : hm.entrySet()) {

				String key = entry.getKey();
				String val = entry.getValue();
				System.out.print("...>"+key + " = " + val + "  ");

			}
		}
		
		/*
		System.out.println("getLocale : "+response.getLocale());
		//System.out.println("getOutputStream : "+response.getOutputStream());
		System.out.println("getBufferSize : "+response.getBufferSize());
		System.out.println("get Character Encoding : "+response.getCharacterEncoding());
		System.out.println("getClass : "+response.getClass());
		//System.out.println("getOutputStream : "+response.getOutputStream());
		System.out.println("getWriter : "+response.getWriter());
		response.setHeader(arg0, arg1);
		 */
		
		
	
		
		Calendar calendar = new GregorianCalendar();
		String am_pm;
	      int hour = calendar.get(Calendar.HOUR);
	      int minute = calendar.get(Calendar.MINUTE);
	      int second = calendar.get(Calendar.SECOND);
	      if(calendar.get(Calendar.AM_PM) == 0)
	        am_pm = "AM";
	      else
	        am_pm = "PM";
	 
	      String CT = hour+":"+ minute +":"+ second +" "+ am_pm;
	      
	      request.setAttribute("Time", CT);
		
		DataHashMap dhm = new DataHashMap();
		HashMap hm=dhm.getData(1);
		System.out.println("\nServlet 1 data : "+hm);
		
		request.setAttribute("AllDetails", al);
		
		response.setIntHeader("Refresh", 5);
		RequestDispatcher rd = request
				.getRequestDispatcher("/jsp/DisplayDetails.jsp");
		rd.forward(request, response); 

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
