package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String userEmail = request.getParameter("email");
		String userPwd = request.getParameter("password");
		
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("email", userEmail);
		hm.put("password", userPwd);
		DataHashMap dhm = new DataHashMap();
		dhm.add(1, request.getParameterMap());
		getServletContext().setAttribute("requestDtat", dhm);
		 
		HttpSession session1=request.getSession();
		session1.setAttribute("email", userEmail);
		session1.setAttribute("password", userPwd);
		
		
	//	session1.invalidate();
		
		ServletContext context = getServletContext();
		String email = context.getInitParameter("email");
		String password = context.getInitParameter("password");

		if (userEmail.equals(email) && userPwd.equals(password)) {

			RequestDispatcher rd = request
					.getRequestDispatcher("/jsp/StudentHome.jsp");
			rd.forward(request, response);

		} else {
			PrintWriter out = response.getWriter();
			out.println("<html>" + "<h3>UserName / Password incorrect</h3"
					+ "<a href=" + request.getContextPath()
					+ "/jsp/Login.jsp>Re_Login</a>" + "</html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
