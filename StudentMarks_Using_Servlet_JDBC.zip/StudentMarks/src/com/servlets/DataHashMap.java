package com.servlets;

import java.util.HashMap;
import java.util.Map;

public class DataHashMap {

	static HashMap<Integer, HashMap<?, ?>> hmap = new HashMap<Integer, HashMap<?, ?>>();

	public void add(int sid, Map<?, ?> hm) {

		hmap.put(sid, (HashMap<?, ?>) hm);

	}

	public HashMap getData(int sid) {

		return hmap.get(sid);

	}

}
