package com.servlets;

import java.io.IOException;
import java.util.LinkedHashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbc.DetailsofStudent;

/**
 * Servlet implementation class UpdateDetailsServlet
 */
public class UpdateDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateDetailsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		LinkedHashMap<String, String> hm = new LinkedHashMap<String, String>();
		String stid = request.getParameter("stid");
		hm.put("sname", request.getParameter("sname"));
		hm.put("email", request.getParameter("email"));
		hm.put("phnum", request.getParameter("phnum"));
		hm.put("sscmaths", request.getParameter("sscmaths"));
		hm.put("ssceng", request.getParameter("ssceng"));
		hm.put("sscscience", request.getParameter("sscscience"));
		
		hm.put("intermaths", request.getParameter("intermaths"));
		hm.put("intereng", request.getParameter("intereng"));
		hm.put("interscience", request.getParameter("interscience"));
		
		hm.put("ugmaths", request.getParameter("ugmaths"));
		hm.put("ugeng", request.getParameter("ugeng"));
		hm.put("ugscience", request.getParameter("ugscience"));

		DetailsofStudent id = new DetailsofStudent();
		id.updateDetails(hm, stid);
		
		//System.out.println(hm);
		
		RequestDispatcher rd = request
				.getRequestDispatcher("jsp/StudentHome.jsp");
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
