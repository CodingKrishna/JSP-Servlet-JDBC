package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class DetailsofStudent {

	public void insertDetails(LinkedHashMap<String, String> hm) {

		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/student", "root", "root");

			// here root is database name, root is username and password
			PreparedStatement stmt = con
					.prepareStatement("insert into studentdetails values(?,?,?,?,?,?,?,?,?,?,?,?,?)");

			Collection<?> c = hm.values();
			Iterator<?> itr = c.iterator();
			int i = 1;
			while (itr.hasNext()) {
				String val = (String) itr.next();
				stmt.setString(i, val);
				System.out.println(val);
				i++;
			}
			stmt.executeUpdate();
			System.out.println("Successfully Inserted");
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@SuppressWarnings("rawtypes")
	public ArrayList<Map> retrieveStudentDetails() {
		ArrayList<Map> al = new ArrayList<Map>();
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/student", "root", "root");

			PreparedStatement ps = con
					.prepareStatement("select * from studentdetails");
			ResultSet rs = ps.executeQuery();
		
		/*	
		 	java.sql.ResultSetMetaData rsmd=rs.getMetaData();
			System.out.println("catalog name : "+rsmd.getCatalogName(1));
			System.out.println("coloumn class name : "+rsmd.getColumnClassName(1));
			System.out.println("coloumn count : "+rsmd.getColumnCount());
			System.out.println("coloumn display size : "+rsmd.getColumnDisplaySize(5));
			System.out.println("catalog name : "+rsmd.getCatalogName(2));
			System.out.println("coloumn label : "+rsmd.getColumnLabel(1));
			System.out.println("coloumn name : "+rsmd.getColumnName(1));
			System.out.println("coloumn type : "+rsmd.getColumnType(1));
			System.out.println("coloumn type name : "+rsmd.getColumnTypeName(1));
			System.out.println("precision : "+rsmd.getPrecision(1));
			System.out.println("getScale + "+rsmd.getScale(1));
			System.out.println("schema name : "+rsmd.getSchemaName(1));
			System.out.println("Table name : "+rsmd.getTableName(1));
			System.out.println("is Auto increment : "+rsmd.isAutoIncrement(1));
			System.out.println("is case sensitive : "+rsmd.isCaseSensitive(1));
			System.out.println("is currency : "+rsmd.isCurrency(1));
			System.out.println("is DefinitelyWritable : "+rsmd.isDefinitelyWritable(1));
			System.out.println("is nullable : "+rsmd.isNullable(1));
			System.out.println("is read only : "+rsmd.isReadOnly(1));
			System.out.println("is searchable : "+rsmd.isSearchable(1));
			System.out.println("is signed : "+rsmd.isSigned(1));
			
			*/
			
			/*
			java.sql.DatabaseMetaData dbmd=con.getMetaData();
			System.out.println("Driver Name : "+dbmd.getDriverName());
			System.out.println("Driver Version : "+dbmd.getDriverVersion());
			System.out.println("User name : "+dbmd.getUserName());
			System.out.println("DatabaseProductName : "+dbmd.getDatabaseProductName());
			System.out.println("DatabaseProductVersion : "+dbmd.getDatabaseProductVersion());
			*/
			
			
			

			while (rs.next()) {
				LinkedHashMap<String, String> m = new LinkedHashMap<String, String>();
				m.put("Student Id", rs.getString(1));
				m.put("Name", rs.getString(2));
				m.put("Email", rs.getString(3));
				m.put("PhoneNum", rs.getString(4));
				m.put("SSC Maths", rs.getString(5));
				m.put("SSC English", rs.getString(6));
				m.put("SSC Science", rs.getString(7));
				
				m.put("Inter Maths", rs.getString(8));
				m.put("Inter English", rs.getString(9));
				m.put("Inter Science", rs.getString(10));
				
				m.put("PG Maths", rs.getString(11));
				m.put("PG English", rs.getString(12));
				m.put("PG Science", rs.getString(13));
				
				al.add(m);
			}
		//	System.out.println("Array List Object: ");
		//	System.out.println(al);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}

	public void updateDetails(LinkedHashMap<String, String> hm, String stid) {

		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/student", "root", "root");
			PreparedStatement stmt = con
					.prepareStatement("update studentdetails set sname=?,email=?,phnum=?, sscmaths=?,ssceng=?,sscscience=? , intermaths=?,intereng=?,interscience=? , ugmaths=?,ugeng=?,ugscience=? where stid="
							+ stid + "");

			Collection<?> c = hm.values();
			Iterator<?> itr = c.iterator();
			int i = 1;
			while (itr.hasNext()) {
				String val = (String) itr.next();
				stmt.setString(i, val);
				i++;
			}
			stmt.executeUpdate();
			System.out.println("updated");

			stmt.executeUpdate();
			System.out.println("updated successfully");
			con.close(); 	

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
