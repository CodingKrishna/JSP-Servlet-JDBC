package org.tclabs.dto;

public class UploadDataInfoDTO {

	private String fieldValue;
	private boolean isFile;
	private String contentType;
	private String fileName;
	private String storedPath;
	private Long fileSize;

	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public boolean getIsFile() {
		return isFile;
	}
	public void setIsFile(boolean isFile) {
		this.isFile = isFile;
	}

	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getFileSize() {
		return fileSize;
	}
	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getStoredPath() {
		return storedPath;
	}
	public void setStoredPath(String storedPath) {
		this.storedPath = storedPath;
	}
	
	@Override
	public String toString() {
		return "UploadDataInfoDTO [fieldValue=" + fieldValue + ", isFile=" + isFile + ", contentType=" + contentType + ", fileName="
				+ fileName + ", fileSize=" + fileSize + "]";
	}
}