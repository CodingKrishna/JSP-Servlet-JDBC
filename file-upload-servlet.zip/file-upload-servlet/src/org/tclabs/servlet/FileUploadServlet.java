package org.tclabs.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.tclabs.dto.UploadDataInfoDTO;

/**
 * Servlet implementation class FileUploadServlet
 */

public class FileUploadServlet extends HttpServlet {
	
	protected String rootPath = "D:\\uploadedFiles";

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileUploadServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.getRequestDispatcher("pages/file-upload.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		List<UploadDataInfoDTO> uploadedData = new ArrayList<UploadDataInfoDTO>();

		boolean isMultiPartContent = ServletFileUpload.isMultipartContent(request);
		if(isMultiPartContent) {
			FileItemFactory fact = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(fact);
			
			try {
				List<FileItem> formFields = upload.parseRequest(request);
				for(int i=0; i<formFields.size(); i++) {
					FileItem item = formFields.get(i);
					
					UploadDataInfoDTO dto = new UploadDataInfoDTO();
					dto.setIsFile(!item.isFormField());
					
					if(dto.getIsFile()) {
						//File Form Field
						dto.setContentType(item.getContentType());
						dto.setFileSize((item.getSize() == 0) ? null : item.getSize());
						dto.setFileName(item.getName());
						
						if(dto.getFileName() != null && dto.getFileName().trim().length() != 0) {
							File file = new File(rootPath, dto.getFileName());
							InputStream is = item.getInputStream();
							FileOutputStream os = new FileOutputStream(file);
							byte[] buffer = new byte[1024];
							int bytesread;
							while((bytesread = is.read(buffer)) != -1) {
								os.write(buffer, 0, bytesread);
							}
							is.close();
							os.close();
							dto.setStoredPath(file.getPath());
						}
					} else {
						//Regular Form Field
						dto.setFieldValue(item.getString());
					}
					if((dto.getIsFile() && dto.getFileName().trim().length() != 0) || !dto.getIsFile())
						uploadedData.add(dto);
				}
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("uploadedData", uploadedData);
		request.getRequestDispatcher("pages/fileresponse.jsp").forward(request, response);
	}
}